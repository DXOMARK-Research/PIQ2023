def print_hello():
    print('Hello, I am an asset.')